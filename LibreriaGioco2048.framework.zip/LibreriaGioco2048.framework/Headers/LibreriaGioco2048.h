//
//  LibreriaGioco2048.h
//  LibreriaGioco2048
//
//  Created by gianluca melchiori on 13/02/2020.
//  Copyright © 2020 gianluca melchiori. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for LibreriaGioco2048.
FOUNDATION_EXPORT double LibreriaGioco2048VersionNumber;

//! Project version string for LibreriaGioco2048.
FOUNDATION_EXPORT const unsigned char LibreriaGioco2048VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LibreriaGioco2048/PublicHeader.h>


